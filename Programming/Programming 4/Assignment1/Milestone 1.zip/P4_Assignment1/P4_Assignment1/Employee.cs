﻿using System;

namespace P4_Assignment1
{
    public class Employee : IComparable<Employee>
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public Employee(int employeeID)
        {
            this.EmployeeID = employeeID;
            this.FirstName = null;
            this.LastName = null;
        }

        public Employee(int employeeID, string firstName, string lastName)
        {
            this.EmployeeID = employeeID;
            this.FirstName = firstName;
            this.LastName = lastName;
        }
        
        public int CompareTo(Employee other)
        {
            return this.EmployeeID.CompareTo(other.EmployeeID);
        }

        public override string ToString()
        {
            if (FirstName == null)
            {
                FirstName = "null";
            }

            if (LastName == null)
            {
                LastName = "null";
            }
            
            return EmployeeID + " " + FirstName + " " + LastName;
        }
    }

    public class Node<T>
    {
        public T Element { get; set; }
        public Node<T> Previous { get; set; }
        public Node<T> Next { get; set; }

        public Node()
        {
            this.Element = default(T);
            this.Previous = default(Node<T>);
            this.Next = default(Node<T>);
        }

        public Node(T Element)
        {
            this.Element = Element;

        }

        public Node(T Element, Node<T> Previous, Node<T> Next)
        {

            this.Element = Element;
            this.Previous = Previous;
            this.Next = Next;

        }

    }

    public class LinkedList<T>
    {
        public Node<T> Head { get; set; }
        public Node<T> Tail { get; set; }
        public int Size { get; set; }

        public LinkedList()
        {
            
        }

        public void AddFirst (T Element)
        {
           
             Node<T> firstnode = new Node<T>(Element);

            Node<T> Oldhead = Head;
            Head = firstnode;

            if (this.Size == 0)
            {
                this.Tail = firstnode;
            }
            else
            {
                this.Head.Next = Oldhead;
                Oldhead.Previous= Head;
            }
            Size++;
        }


        public void Clear()
        {

            Size = 0;
            Head = null;
            Tail = null;

        }

        public bool IsEmpty()
        {
            return this.Size == 0;
            //if (this.Size == 0)
            //{
            //    return true;
            //}

            //else
            //{
            //    return false;
            //}
        }

        public Node<T> GetHead()
        {
            return this.Head;
        }

        public Node<T> GetTail()
        {
            return this.Tail;
        }

        public T GetFirst()
        {
            if (IsEmpty())
            {
                throw new ApplicationException("No Head to get");
            }
            else
            {
                return Head.Element;
            }
        }

        public T  GetLast()
        {
            if (IsEmpty())
            {
                throw new ApplicationException("No Tail to get");
            }
            else
            {
                return Tail.Element;
            }
            
        }

        public int GetSize()
        {
            return this.Size;
        }

        public void SetFirst(Node<T> element)
        {
            this.Head = element;
        }

        public void SetLast(Node<T> element)
        {
            this.Tail = element;
        }


    }
}
