﻿using NUnit.Framework;
using P4_Assignment1;
using System;

namespace TestLibrary
{
    /// <summary>
    /// IMPORTANT NOTE: Uncomment each test and ensure it works by building
    ///                 out the appropriate class and methods.
    ///                 DO NOT CHANGE THE TEST CODE!! EVER. :)
    /// LinkedListTest - A class for testing the LinkedList class
    /// LinkedList - A class for creating and manipulating a doubly linked list of nodes containing generic data of type T.
    /// 
    /// Assignment:     #1
    /// Course:         ADEV-3001
    /// Date Created:   August. 31, 2018
    /// 
    /// Revision Log
    /// Who         When        Reason
    /// ----------- ----------- ---------------
    /// 
    /// @author: Scott Wachal
    /// @version 1.0
    /// </summary>
    [TestFixture]
    public class LinkedListTest
    {
        #region Milestone 1

        #region Constructor Tests, requires GetHead(), GetTail(), GetSize(), IsEmpty()
        /// <summary>
        /// Test the constructor to ensure the default values are set properly.
        /// </summary>
        [Test]
        public void new_constructor_has_size_of_zero_Test()
        {
            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(list.GetSize(), Is.EqualTo(0));
        }

        [Test]
        /// <summary>
        /// Test GetHead returns null when a new constructor is called.
        /// </summary>
        public void GetHead_is_null_on_new_constructor_Test()
        {
            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(list.GetHead(), Is.EqualTo(null));
        }

        [Test]
        /// <summary>
        /// Test GetTail returns null when a new constructor is called.
        /// </summary>
        public void GetTail_is_null_on_new_constructor_Test()
        {
            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(list.GetTail(), Is.EqualTo(null));
        }

        /// <summary>
        /// Test IsEmpty() should return true on an empty list.
        /// </summary>
        [Test]
        public void IsEmpty_is_true_on_new_constructor_Test()
        {
            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(list.IsEmpty(), Is.True);
        }
        #endregion

        #region AddFirst(), requires: GetSize() / GetHead() / GetTail()
        /// <summary>
        /// Test AddFirst() to ensure node is added to list.
        /// </summary>
        [Test]
        public void AddFirst_on_emptylist_count_increases_from_0_to_1_Test()
        {
            Employee addedEmployee = new Employee(1);
            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(list.GetSize(), Is.EqualTo(0));

            list.AddFirst(addedEmployee);

            Assert.That(list.GetSize(), Is.EqualTo(1));
        }

        /// <summary>
        /// Test AddFirst() method to ensure the head pointer is updated when first object is inserted.
        /// </summary>
        [Test]
        public void AddFirst_on_emptylist_Head_Updated_Test()
        {
            Employee employee1 = new Employee(1);

            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(list.GetHead(), Is.EqualTo(null));

            list.AddFirst(employee1);

            Assert.That(list.GetHead().Element, Is.EqualTo(employee1));
        }

        /// <summary>
        /// Test AddFirst() method to ensure the head pointer is updated when many objects are inserted.
        /// </summary>
        [Test]
        public void AddFirst_on_larger_Existing_list_Head_Updated_Test()
        {
            Employee employee1 = new Employee(1);
            Employee employee2 = new Employee(2);
            Employee employee3 = new Employee(3);

            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(list.GetHead(), Is.EqualTo(null));

            list.AddFirst(employee1);
            list.AddFirst(employee2);
            list.AddFirst(employee3);

            Assert.That(list.GetHead().Element, Is.EqualTo(employee3));
        }

        /// <summary>
        /// Test AddFirst() method to ensure the tail pointer is updated when first object is inserted.
        /// </summary>
        [Test]
        public void AddFirst_on_emptylist_Tail_Updated_Test()
        {
            Employee employee1 = new Employee(1);

            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(list.GetTail(), Is.EqualTo(null));

            list.AddFirst(employee1);

            Assert.That(list.GetTail().Element, Is.EqualTo(employee1));
        }

        /// <summary>
        /// Test AddFirst() to ensure that the added node is added to the head position when more than one node is in the list.
        /// </summary>
        [Test]
        public void AddFirst_on_existinglist_count_increases_from_1_to_2_Test()
        {
            Employee employeeInList = new Employee(1);
            Employee addedEmployee = new Employee(2);

            LinkedList<Employee> list = new LinkedList<Employee>();
            Assert.That(list.GetSize(), Is.EqualTo(0));

            list.AddFirst(employeeInList);
            Assert.That(list.GetSize(), Is.EqualTo(1));

            list.AddFirst(addedEmployee);
            Assert.That(list.GetSize(), Is.EqualTo(2));
        }

        /// <summary>
        /// Test AddFirst() method to ensure the head pointer is updated when many objects are inserted.
        /// </summary>
        [Test]
        public void AddFirst_on_larger_Existing_list_Tail_Updated_Test()
        {
            Employee employee1 = new Employee(1);
            Employee employee2 = new Employee(2);
            Employee employee3 = new Employee(3);

            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(list.GetHead(), Is.EqualTo(null));

            list.AddFirst(employee1);
            list.AddFirst(employee2);
            list.AddFirst(employee3);

            Assert.That(list.GetTail().Element, Is.EqualTo(employee1));
        }

        /// <summary>
        /// Test AddFirst() to ensure it can handle null being added to list.
        /// </summary>
        [Test]
        public void AddFirst_null_element_is_allowed_Test()
        {
            LinkedList<Employee> list = new LinkedList<Employee>();

            list.AddFirst(null);

            Assert.That(list.GetSize(), Is.EqualTo(1));
            Assert.That(list.GetFirst(), Is.Null);
        }

        /// <summary>
        /// Test AddFirst() method to ensure the old head pointer's previous now points to the new head.
        /// </summary>
        [Test]
        public void AddFirst_on_existingList_updates_oldhead_to_point_previous_to_newhead_Test()
        {
            Employee employee1 = new Employee(1);
            Employee employee2 = new Employee(2);

            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(list.GetHead(), Is.EqualTo(null));

            list.AddFirst(employee1);
            Node<Employee> oldHead = list.GetHead();

            list.AddFirst(employee2);
            Node<Employee> newHead = list.GetHead();

            Assert.That(newHead.Element, Is.EqualTo(employee2));
            Assert.That(newHead.Previous, Is.EqualTo(null));
            Assert.That(newHead.Next.Element, Is.EqualTo(oldHead.Element));

            Assert.That(oldHead.Element, Is.EqualTo(employee1));
            Assert.That(oldHead.Previous.Element, Is.EqualTo(newHead.Element));
            Assert.That(oldHead.Next, Is.EqualTo(null));
        }

        #endregion

        #region GetFirst() and GetLast()

        /// <summary>
        /// Test that GetFirst throws an exception when called on an empty list, because Null.Element doesn't exist!
        /// </summary>
        [Test]
        public void GetFirst_on_emptylist_throws_exception_Test()
        {
            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(() => list.GetFirst(), Throws.Exception.TypeOf<ApplicationException>());
        }

        /// <summary>
        /// Test that GetFirst returns the head's element
        /// </summary>
        [Test]
        public void GetFirst_on_existinglist_returns_head_element_Test()
        {
            LinkedList<Employee> list = new LinkedList<Employee>();
            list.AddFirst(new Employee(1));

            Assert.That(list.GetHead().Element, Is.EqualTo(list.GetFirst()));
        }

        /// <summary>
        /// Test that GetLast throws an exception when called on an empty list, because Null.Element doesn't exist!
        /// </summary>
        [Test]
        public void GetLast_on_emptylist_throws_exception_Test()
        {
            LinkedList<Employee> list = new LinkedList<Employee>();

            Assert.That(() => list.GetLast(), Throws.Exception.TypeOf<ApplicationException>());
        }

        /// <summary>
        /// Test that GetLast returns the tail's element
        /// </summary>
        [Test]
        public void GetLast_on_existinglist_returns_tail_element_Test()
        {
            LinkedList<Employee> list = new LinkedList<Employee>();
            list.AddFirst(new Employee(1));

            Assert.That(list.GetTail().Element, Is.EqualTo(list.GetLast()));
        }
        #endregion

        #region IsEmpty()
        /// <summary>
        /// Test IsEmpty() should return false on a list containing nodes.
        /// </summary>
        [Test]
        public void IsEmpty_returns_false_on_existinglist_Test()
        {
            Employee employee = new Employee(1);

            LinkedList<Employee> list = new LinkedList<Employee>();
            list.AddFirst(employee);

            Assert.That(list.IsEmpty(), Is.False);
        }
        #endregion

        #region Clear()
        /// <summary>
        /// Test that Clear() empties a list.
        /// </summary>
        [Test]
        public void ClearTest()
        {
            Employee employee1 = new Employee(1);
            Employee employee2 = new Employee(2);
            Employee employee3 = new Employee(3);

            LinkedList<Employee> list = new LinkedList<Employee>();

            list.AddFirst(employee3);
            list.AddFirst(employee2);
            list.AddFirst(employee1);

            Assert.That(list.GetSize(), Is.EqualTo(3));
            Assert.That(list.IsEmpty, Is.EqualTo(false));

            list.Clear();

            Assert.That(list.GetSize(), Is.EqualTo(0));
            Assert.That(list.IsEmpty, Is.EqualTo(true));
        }

        /// <summary>
        /// Test that calling Clear() on an empty list doesn't throw an exception.
        /// </summary>
        [Test]
        public void ClearEmptyListTest()
        {
            LinkedList<Employee> list = new LinkedList<Employee>();

            try
            {
                list.Clear();
            }
            catch (Exception)
            {
                Assert.Fail("Clear() should not have thrown exception.");
            }

            Assert.Pass("Clear() did not throw exception.");
        }
        #endregion

        #region GetSize()
        /// <summary>
        /// Test GetSize() to make sure it returns the proper size; mostly for fun here. :)
        /// </summary>
        [Test]
        public void GetSize_returns_correct_value_after_random_adds_Test()
        {
            Random rnd = new Random();
            int numberOfElements = rnd.Next(1, 50);

            Employee employee = new Employee(1);
            LinkedList<Employee> list = new LinkedList<Employee>();

            for (int i = 0; i < numberOfElements; i++)
            {
                list.AddFirst(employee);
            }

            Assert.That(list.GetSize(), Is.EqualTo(numberOfElements));
        }
        #endregion
        #endregion

        //#region Milestone 2

        //#region AddLast()
        ///// <summary>
        ///// Test AddLast() to ensure node is added to list.
        ///// </summary>
        //[Test]
        //public void AddLast_to_emptyList_count_increases_Test()
        //{
        //    Employee addedEmployee = new Employee(1);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(addedEmployee);

        //    Assert.That(list.GetSize(), Is.EqualTo(1));
        //}

        ///// <summary>
        ///// Test AddLast() to ensure node is added to list.
        ///// </summary>
        //[Test]
        //public void AddLast_to_emptyList_last_updated_Test()
        //{
        //    Employee addedEmployee = new Employee(1);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(addedEmployee);

        //    Assert.That(list.GetLast(), Is.EqualTo(addedEmployee));
        //}
        ///// <summary>
        ///// Test AddLast() to ensure node is added to list.
        ///// </summary>
        //[Test]
        //public void AddLast_to_emptyList_first_updated_Test()
        //{
        //    Employee addedEmployee = new Employee(1);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(addedEmployee);

        //    Assert.That(list.GetFirst(), Is.EqualTo(addedEmployee));
        //}

        ///// <summary>
        ///// Test AddLast() to ensure node is added to list.
        ///// </summary>
        //[Test]
        //public void AddLast_to_emptyList_tail_pointers_are_set_to_null_Test()
        //{
        //    Employee addedEmployee = new Employee(1);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(addedEmployee);

        //    Assert.That(list.GetTail().Next, Is.EqualTo(null));
        //    Assert.That(list.GetTail().Previous, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Test AddLast() to ensure that the added node is added to the tail position when more than one node is in the list.
        ///// </summary>
        //[Test]
        //public void AddLast_to_existingList_tail_previous_set_to_oldTail_Test()
        //{
        //    Employee employeeInList = new Employee(1);
        //    Employee addedEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employeeInList);
        //    Node<Employee> oldTail = list.GetTail();

        //    list.AddLast(addedEmployee);
        //    Node<Employee> newTail = list.GetTail();

        //    Assert.That(list.GetSize(), Is.EqualTo(2));
        //    Assert.That(list.GetLast(), Is.EqualTo(addedEmployee));
        //    Assert.That(newTail.Previous, Is.EqualTo(oldTail));
        //}

        ///// <summary>
        ///// Test AddLast() to ensure that the added node is added to the tail position of the list in a larger list.
        ///// </summary>
        //[Test]
        //public void AddLast_to_larger_existingList_first_and_last_are_updated_Test()
        //{
        //    Employee employeeInList = new Employee(1);
        //    Employee employeeInList2 = new Employee(2);
        //    Employee addedEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employeeInList);
        //    list.AddLast(employeeInList2);
        //    list.AddLast(addedEmployee);

        //    Assert.That(list.GetSize(), Is.EqualTo(3));
        //    Assert.That(list.GetFirst(), Is.EqualTo(employeeInList));
        //    Assert.That(list.GetLast(), Is.EqualTo(addedEmployee));
        //}

        ///// <summary>
        ///// Test AddLast() to ensure it can handle null being added to list.
        ///// </summary>
        //[Test]
        //public void AddLast_Null_element_is_allowed_Test()
        //{
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(null);

        //    Assert.That(list.GetSize(), Is.EqualTo(1));
        //    Assert.That(list.GetFirst(), Is.Null);
        //    Assert.That(list.GetLast(), Is.Null);
        //}
        //#endregion

        //#region RemoveFirst()
        ///// <summary>
        ///// Test calling RemoveFirst() on an empty list causes an exception.
        ///// </summary>
        //[Test]
        //public void RemoveFirst_on_EmptyList_throws_exception_test()
        //{
        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.RemoveFirst(), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Test RemoveFirst() returns reduced count by 1
        ///// </summary>
        //[Test]
        //public void RemoveFirst_decreases_count_by_1_Test()
        //{
        //    Employee employee1 = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);
        //    Assert.That(list.GetSize(), Is.EqualTo(1));
        //    list.RemoveFirst();
        //    Assert.That(list.GetSize(), Is.EqualTo(0));
        //}

        ///// <summary>
        ///// Test RemoveFirst() returns the element removed.
        ///// </summary>
        //[Test]
        //public void RemoveFirst_Returns_first_Element_Test()
        //{
        //    Employee employee1 = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);
        //    var firstElement = list.GetFirst();
        //    var returnedElement = list.RemoveFirst();

        //    Assert.That(returnedElement, Is.EqualTo(firstElement));
        //}

        ///// <summary>
        ///// Test RemoveFirst() removes the head and tail on size 1 list
        ///// </summary>
        //[Test]
        //public void RemoveFirst_on_list_of_size_1_removes_head_and_tail_Test()
        //{
        //    Employee employee1 = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);
        //    list.RemoveFirst();

        //    Assert.That(list.IsEmpty(), Is.EqualTo(true));
        //    Assert.That(list.GetHead(), Is.EqualTo(null));
        //    Assert.That(list.GetTail(), Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Test RemoveFirst() removes the head node on a larger list
        ///// </summary>
        //[Test]
        //public void RemoveFirst_on_larger_existingList_removes_head_and_decreases_count_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee3);
        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);
        //    Assert.That(list.GetSize(), Is.EqualTo(3));
        //    Assert.That(list.GetFirst(), Is.EqualTo(employee1));
        //    list.RemoveFirst();

        //    Assert.That(list.GetSize(), Is.EqualTo(2));
        //    Assert.That(list.GetFirst(), Is.EqualTo(employee2));
        //}

        ///// <summary>
        ///// Test RemoveFirst() removes the head node and sets previous to null
        ///// </summary>
        //[Test]
        //public void RemoveFirst_on_existingList_removes_head_and_sets_previous_to_null_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee3);
        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);

        //    list.RemoveFirst();

        //    Assert.That(list.GetHead().Previous, Is.EqualTo(null));
        //    Assert.That(list.GetHead().Next.Element, Is.EqualTo(employee3));
        //}

        //#endregion

        //#region RemoveLast()
        ///// <summary>
        ///// Test calling RemoveLast() on an empty list causes an exception.
        ///// </summary>
        //[Test]
        //public void RemoveLast_on_EmptyList_throws_exception_test()
        //{
        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.RemoveLast(), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Test RemoveLast() decreases count by 1.
        ///// </summary>
        //[Test]
        //public void RemoveLast_decreases_count_by_1_Test()
        //{
        //    Employee employee1 = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);
        //    Assert.That(list.GetSize(), Is.EqualTo(1));
        //    list.RemoveLast();

        //    Assert.That(list.GetSize(), Is.EqualTo(0));
        //}

        ///// <summary>
        ///// Test RemoveLast() returns the element removed.
        ///// </summary>
        //[Test]
        //public void RemoveLast_Returns_last_Element_Test()
        //{
        //    Employee employee1 = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);
        //    var lastElement = list.GetLast();
        //    var returnedElement = list.RemoveLast();

        //    Assert.That(returnedElement, Is.EqualTo(lastElement));
        //}

        ///// <summary>
        ///// Test RemoveLast() removes head and tail on size 1 list
        ///// </summary>
        //[Test]
        //public void RemoveLast_on_list_of_size_1_removes_head_and_tail_Test()
        //{
        //    Employee employee1 = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);

        //    list.RemoveLast();

        //    Assert.That(list.IsEmpty(), Is.EqualTo(true));
        //    Assert.That(list.GetHead(), Is.EqualTo(null));
        //    Assert.That(list.GetTail(), Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Test RemoveLast() removes the tail node on a larger list
        ///// </summary>
        //[Test]
        //public void RemoveLast_on_larger_existingList_removes_tail_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee3);
        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);
        //    Assert.That(list.GetSize(), Is.EqualTo(3));
        //    Assert.That(list.GetLast(), Is.EqualTo(employee3));

        //    list.RemoveLast();

        //    Assert.That(list.GetSize(), Is.EqualTo(2));
        //    Assert.That(list.GetLast(), Is.EqualTo(employee2));

        //    Assert.That(list.GetTail().Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Test RemoveLast() on two items, removes the tail node and sets head to tail.
        ///// </summary>
        //[Test]
        //public void RemoveLast_on_list_of_size_2_makes_the_head_the_newTail_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employee1);
        //    list.AddLast(employee2);

        //    list.RemoveLast();

        //    Assert.That(list.GetHead(), Is.EqualTo(list.GetTail()));
        //    Assert.That(list.GetTail().Next, Is.Null);
        //    Assert.That(list.GetTail().Previous, Is.Null);
        //    Assert.That(list.GetFirst(), Is.EqualTo(employee1));
        //    Assert.That(list.GetLast(), Is.EqualTo(employee1));
        //}

        //#endregion

        //#region SetFirst(element)
        ///// <summary>
        ///// Test SetFirst() on an empty list raises an exception.
        ///// </summary>
        //[Test]
        //public void SetFirst_on_emptyList_throws_exception_Test()
        //{
        //    Employee employee1 = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.SetFirst(employee1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Test SetFirst() replaces element on the head node on list of 1
        ///// </summary>
        //[Test]
        //public void SetFirst_on_list_of_1_replaces_head_element_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);

        //    list.SetFirst(employee2);

        //    Assert.That(list.GetFirst(), Is.EqualTo(employee2));
        //}

        ///// <summary>
        ///// Test SetFirst() returns the element that has been replaced.
        ///// </summary>
        //[Test]
        //public void SetFirst_Returns_ReplacedElement_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);

        //    var returnedData = list.SetFirst(employee2);

        //    Assert.That(returnedData, Is.EqualTo(employee1));
        //}

        //#endregion

        //#region SetLast(element)

        ///// <summary>
        ///// Test SetLast() on an empty list raises an exception.
        ///// </summary>
        //[Test]
        //public void SetLast_on_emptyList_throws_exception_Test()
        //{
        //    Employee employee1 = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.SetLast(employee1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Test SetLast() replaces element on the tail node.
        ///// </summary>
        //[Test]
        //public void SetLast_on_existingList_updates_tail_element_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);
        //    list.AddFirst(employee2);

        //    list.SetLast(employee3);

        //    Assert.That(list.GetLast(), Is.EqualTo(employee3));
        //}

        ///// <summary>
        ///// Test SetLast() returns the element that has been replaced.
        ///// </summary>
        //[Test]
        //public void SetLast_returns_replaced_element_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);
        //    list.AddFirst(employee2);

        //    var returnedData = list.SetLast(employee3);

        //    Assert.That(returnedData, Is.EqualTo(employee1));
        //}
        //#endregion

        //#region Get(position)
        ///// <summary>
        ///// Ensure that Get(position) returns the element at the correct position.
        ///// </summary>
        //[Test]
        //public void Get_By_Position_1_on_existingList_returns_head_element_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);

        //    Assert.That(list.Get(1), Is.EqualTo(list.GetFirst()));
        //}

        ///// <summary>
        ///// Make sure that calling Get(position) on an empty list results in an exception.
        ///// </summary>
        //[Test]
        //public void Get_By_Position_On_EmptyList_throws_exception_Test()
        //{
        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.Get(1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Make sure at calling Get(position) with a negative number results in an exception.
        ///// </summary>
        //[Test]
        //public void Get_By_number_less_than_1_on_existingList_throws_exception_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);

        //    Assert.That(() => list.Get(-1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that Get(position) returns the element at the correct position.
        ///// </summary>
        //[Test]
        //public void Get_By_Position_2_on_list_of_size_2_returns_last_element_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);

        //    Assert.That(list.Get(2), Is.EqualTo(list.GetLast()));
        //}

        ///// <summary>
        ///// Ensure that calling Get(positoin) with a value larger than the size of the list results in an exception.
        ///// </summary>
        //[Test]
        //public void Get_By_Position_larger_than_list_size_throws_exception_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);

        //    Assert.That(() => list.Get(list.GetSize() + 1), Throws.Exception.TypeOf<ApplicationException>());
        //}
        //#endregion

        //#region AddAfter(element, position)
        ///// <summary>
        ///// Ensure that calling AddAfter() on an empty list will result in an exception.
        ///// </summary>
        //[Test]
        //public void AddAfterPosition_on_EmptyList_throws_exception_test()
        //{
        //    Employee employee = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.AddAfter(employee, 1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that passing a negative position value to AddAfter(element, position) results in an exception.
        ///// </summary>
        //[Test]
        //public void AddAfterPosition_Negative_Position_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee addEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.AddAfter(addEmployee, -1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that passing a position value larger than size to AddAfter(element, position) results in an exception.
        ///// </summary>
        //[Test]
        //public void AddAfterPosition_getsize_plus_1_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee addEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.AddAfter(addEmployee, list.GetSize() + 1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Make sure element is inserted into proper position.
        ///// </summary>
        //[Test]
        //public void AddAfter_Position_1_on_existingList_inserts_after_head_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee3);
        //    list.AddFirst(employee1);

        //    list.AddAfter(employee2, 1);

        //    Assert.That(list.GetHead().Next.Element, Is.EqualTo(employee2));

        //    Assert.That(list.GetSize(), Is.EqualTo(3));
        //    Assert.That(list.Get(1), Is.EqualTo(employee1));
        //    Assert.That(list.Get(2), Is.EqualTo(employee2));
        //    Assert.That(list.Get(3), Is.EqualTo(employee3));
        //}

        ///// <summary>
        ///// Checking edge case; Ensure that passing the size as the position will append to the end of the list without error.
        ///// </summary>
        //[Test]
        //public void AddAfterPosition_using_GetSize_on_existingList_returns_tail_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);

        //    list.AddAfter(employee3, list.GetSize());

        //    Assert.That(list.GetSize(), Is.EqualTo(3));
        //    Assert.That(list.Get(1), Is.EqualTo(employee1));
        //    Assert.That(list.Get(2), Is.EqualTo(employee2));
        //    Assert.That(list.Get(3), Is.EqualTo(employee3));
        //}

        //#endregion

        //#region AddBefore(element, positon)
        ///// <summary>
        ///// Ensure that calling AddBefore() on an empty list will result in an exception.
        ///// </summary>
        //[Test]
        //public void AddBeforePosition_on_EmptyList_throws_exception_test()
        //{
        //    Employee employee = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.AddAfter(employee, 1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that passing a negative position value to AddBefore(element, position) results in an exception.
        ///// </summary>
        //[Test]
        //public void AddBeforePosition_Negative_Position_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee addEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.AddBefore(addEmployee, -1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that passing a position value larger than size to AddBefore(element, position) results in an exception.
        ///// </summary>
        //[Test]
        //public void AddBeforePosition_getsize_plus_1_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee addEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.AddBefore(addEmployee, list.GetSize() + 1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Make sure element is inserted into proper position.
        ///// </summary>
        //[Test]
        //public void AddBefore_Position_1_on_existingList_updates_First_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee3);
        //    list.AddFirst(employee1);

        //    list.AddBefore(employee2, 1);

        //    Assert.That(list.GetFirst(), Is.EqualTo(employee2));

        //    Assert.That(list.GetSize(), Is.EqualTo(3));
        //    Assert.That(list.Get(1), Is.EqualTo(employee2));
        //    Assert.That(list.Get(2), Is.EqualTo(employee1));
        //    Assert.That(list.Get(3), Is.EqualTo(employee3));
        //}

        ///// <summary>
        ///// Checking edge case; Ensure that passing the size as the position will append to the end of the list without error.
        ///// </summary>
        //[Test]
        //public void AddBeforePosition_using_GetSize_on_existingList_inserts_tails_previous_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);

        //    list.AddBefore(employee3, list.GetSize());
        //    Assert.That(list.GetTail().Previous.Element, Is.EqualTo(employee3));

        //    Assert.That(list.GetSize(), Is.EqualTo(3));
        //    Assert.That(list.Get(1), Is.EqualTo(employee1));
        //    Assert.That(list.Get(2), Is.EqualTo(employee3));
        //    Assert.That(list.Get(3), Is.EqualTo(employee2));
        //}
        //#endregion

        //#region Remove(position)
        ///// <summary>
        ///// Make sure that calling Remove(position) on an empty list results in an exception.
        ///// </summary>
        //[Test]
        //public void RemoveByPosition_On_EmptyList_throw_exception_Test()
        //{
        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.Remove(1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Make sure at calling Remove(position) with a negative number results in an exception.
        ///// </summary>
        //[Test]
        //public void RemoveByPosition_Negative_number_throws_exception_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);

        //    Assert.That(() => list.Remove(-1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that calling Remove(position) with a value of zero results in an exception.
        ///// </summary>
        //[Test]
        //public void RemoveByPosition_Zero_throws_exception_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);

        //    Assert.That(() => list.Remove(0), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that calling Remove(position) with a value larger than the size of the list results in an exception.
        ///// </summary>
        //[Test]
        //public void RemoveByPosition_getsize_plus_one_throws_exception_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);

        //    Assert.That(() => list.Remove(100), Throws.Exception.TypeOf<ApplicationException>());
        //}


        ///// <summary>
        ///// Ensure that Remove() decreases count
        ///// </summary>
        //[Test]
        //public void RemoveByPosition_decreases_count_by_one_Test()
        //{
        //    Employee employee1 = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee1);

        //    Assert.That(list.GetSize(), Is.EqualTo(1));

        //    var returnedElement = list.Remove(1);

        //    Assert.That(list.GetSize(), Is.EqualTo(0));
        //}


        ///// <summary>
        ///// Ensure that Remove() returns the element removed.
        ///// </summary>
        //[Test]
        //public void RemoveByPosition_Returns_an_Element_Test()
        //{
        //    Employee employee1 = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee1);

        //    var returnedElement = list.Remove(1);

        //    Assert.That(returnedElement, Is.EqualTo(employee1));
        //}

        ///// <summary>
        ///// Ensure that Remove() removes the element at the correct position.
        ///// </summary>
        //[Test]
        //public void RemoveByPosition_2_in_list_of_size_3_removes_the_right_node_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee1);
        //    list.AddFirst(employee2);
        //    list.AddFirst(employee3);

        //    Assert.That(list.GetSize(), Is.EqualTo(3));

        //    list.Remove(2);

        //    Assert.That(list.GetSize(), Is.EqualTo(2));
        //    Assert.That(list.GetFirst(), Is.EqualTo(employee3));
        //    Assert.That(list.GetLast(), Is.EqualTo(employee1));
        //}

        ///// <summary>
        ///// Test Remove(position) properly updated the head when removing from position 1.
        ///// </summary>
        //[Test]
        //public void RemoveByPosition_Head_Updated_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee1);
        //    list.AddLast(employee2);
        //    list.AddLast(employee3);

        //    Employee removedElement = list.Remove(1);

        //    Assert.That(removedElement, Is.EqualTo(employee1));
        //    Assert.That(list.GetFirst(), Is.EqualTo(employee2));
        //    Assert.That(list.GetHead().Next.Element, Is.EqualTo(employee3));
        //    Assert.That(list.GetHead().Previous, Is.Null);
        //}

        ///// <summary>
        ///// Test Remove(position) properly updates the tail when removing from position size.
        ///// </summary>
        //[Test]
        //public void RemoveByPosition_Tail_Updated_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee1);
        //    list.AddLast(employee2);
        //    list.AddLast(employee3);

        //    Assert.That(list.GetLast(), Is.EqualTo(employee3));

        //    Employee removedElement = list.Remove(list.GetSize());

        //    Assert.That(removedElement, Is.EqualTo(employee3));

        //    Assert.That(list.GetLast(), Is.EqualTo(employee2));
        //    Assert.That(list.GetTail().Next, Is.Null);
        //    Assert.That(list.GetTail().Previous.Element, Is.EqualTo(employee1));
        //}

        //#endregion

        //#region Set(element, position)
        ///// <summary>
        ///// Test Set(position) on an empty list results in an exception.
        ///// </summary>
        //[Test]
        //public void SetByPosition_On_EmptyList_throws_exception_Test()
        //{
        //    Employee employee1 = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.Set(employee1, 1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Test Set(position) with a negative number results in an exception.
        ///// </summary>
        //[Test]
        //public void SetByPosition_Negative_Value_throws_exception_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee1);

        //    Assert.That(() => list.Set(employee2, -1), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Test Set(position) with a value of zero results in an exception.
        ///// </summary>
        //[Test]
        //public void SetByPosition_Zero_throws_exception_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee1);

        //    Assert.That(() => list.Set(employee2, 0), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Test Set(position) with a value larger than the size of the list results in an exception.
        ///// </summary>
        //[Test]
        //public void SetByPositionLargerThanSizeTest()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee1);

        //    Assert.That(() => list.Set(employee2, 100), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that Set(position) sets the element at the correct position.
        ///// </summary>
        //[Test]
        //public void SetByPosition_1_on_list_of_1_updates_element_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);

        //    Assert.That(list.Get(1), Is.EqualTo(employee1));

        //    list.Set(employee2, 1);

        //    Assert.That(list.GetSize(), Is.EqualTo(1));
        //    Assert.That(list.Get(1), Is.EqualTo(employee2));
        //}

        ///// <summary>
        ///// Test Set(position) returns the replaced element.
        ///// </summary>
        //[Test]
        //public void SetByPosition_Returns_old_Element_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);

        //    var returnedData = list.Set(employee2, 1);

        //    Assert.That(returnedData, Is.EqualTo(employee1));
        //}

        ///// <summary>
        ///// Ensure that Set(position) sets the element at the correct position.
        ///// </summary>
        //[Test]
        //public void SetByPosition_3_on_list_of_3_updates_element_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);
        //    Employee employee4 = new Employee(4);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employee1);
        //    list.AddLast(employee2);
        //    list.AddLast(employee3);

        //    Assert.That(list.GetSize(), Is.EqualTo(3));
        //    Assert.That(list.Get(list.GetSize()), Is.EqualTo(employee3));

        //    Employee returnedData = list.Set(employee4, list.GetSize());

        //    Assert.That(list.GetSize(), Is.EqualTo(3));
        //    Assert.That(list.Get(list.GetSize()), Is.EqualTo(employee4));
        //    Assert.That(returnedData, Is.EqualTo(employee3));
        //}
        //#endregion
        //#endregion

        //#region Milestone 3

        //#region Get(element)
        ///// <summary>
        ///// Ensure that Get by element returns the element at the correct element.
        ///// </summary>
        //[Test]
        //public void GetByElement_returns_the_element_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1);

        //    Assert.That(list.Get(employee1).CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(list.Get(employee2).CompareTo(employee2), Is.EqualTo(0));
        //}

        ///// <summary>
        ///// Make sure that Get(element) on an empty list results in an exception.
        ///// </summary>
        //[Test]
        //public void GetByElement_On_EmptyList_throw_exception_Test()
        //{
        //    Employee employee = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.Get(employee), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that calling Get(element) with element that is not in the list results in an exception.
        ///// </summary>
        //[Test]
        //public void GetByElement_no_match_found_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee missingEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.Get(missingEmployee), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that calling Get(element) with element that matches multiple list elements returns only one result.
        ///// </summary>
        //[Test]
        //public void GetByElement_Multiple_matches_found_returns_first_match_test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee employee2 = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employee);
        //    list.AddLast(employee2);
        //    list.AddLast(employee);

        //    Assert.That(list.Get(employee).CompareTo(employee), Is.EqualTo(0));
        //}
        //#endregion

        //#region AddAfter(element, oldElement)
        ///// <summary>
        ///// Ensure that calling AddAfter(element) on an empty list will result in an exception.
        ///// </summary>
        //[Test]
        //public void AddAfterByElement_on_EmptyList_throws_exception_test()
        //{
        //    Employee employee = new Employee(1);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    Assert.That(() => list.AddAfter(employee, employee), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that passing element that is not in the list to AddAfter(element) results in an exception.
        ///// </summary>
        //[Test]
        //public void AddAfterByElement_no_match_found_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee addEmployee = new Employee(2);
        //    Employee nonListEmployee = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.AddAfter(addEmployee, nonListEmployee), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that passing null value to AddAfter(element, position) results in an exception.
        ///// </summary>
        //[Test]
        //public void AddAfterByElement_when_element_is_null_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee addEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.AddAfter(addEmployee, null), Throws.Exception.TypeOf<ArgumentNullException>());
        //}

        ///// <summary>
        ///// Checking edge case; Ensure that passing the tail element as the element will append to the end of the list without error.
        ///// </summary>
        //[Test]
        //public void AddAfterByElement_Tail_updated_and_count_increases_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee2);
        //    list.AddFirst(employee1);
        //    Assert.That(list.GetSize(), Is.EqualTo(2));

        //    list.AddAfter(employee3, list.GetLast()); // adds after 2

        //    Assert.That(list.GetSize(), Is.EqualTo(3));

        //    var head = list.GetHead();
        //    var middle = head.Next;
        //    var tail = list.GetTail();

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(middle.Element.CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0)); // new tail is 3

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(tail.Previous, Is.EqualTo(middle));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Make sure element is inserted into proper position.
        ///// </summary>
        //[Test]
        //public void AddAfterByElement_adds_appropriately_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee3);
        //    list.AddFirst(employee1);
        //    list.AddAfter(employee2, employee1); // between 1 & 3

        //    var head = list.GetHead();
        //    var middle = head.Next;
        //    var tail = list.GetTail();

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(head.Element, Is.EqualTo(list.Get(1)));

        //    Assert.That(middle.Element.CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(middle.Element, Is.EqualTo(list.Get(2)));

        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0));
        //    Assert.That(tail.Element, Is.EqualTo(list.Get(3)));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(tail.Previous, Is.EqualTo(middle));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Ensure that passing a element that appears multiple times in the list to AddAfter(element, oldElement) element is inserted after first instance.
        ///// </summary>
        //[Test]
        //public void AddAfterByElement_multiple_match_found_adds_after_first_instance_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee addEmployee = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);
        //    list.AddFirst(employee2);
        //    list.AddFirst(employee); // order will be: 1, 2, 1

        //    list.AddAfter(addEmployee, employee); // order should be: 1, 3, 2, 1

        //    var head = list.GetHead();
        //    var afterHead = head.Next;
        //    var tail = list.GetTail();
        //    var beforeTail = tail.Previous;

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee), Is.EqualTo(0));
        //    Assert.That(head.Element.CompareTo(list.Get(1)), Is.EqualTo(0));

        //    Assert.That(afterHead.Element.CompareTo(addEmployee), Is.EqualTo(0)); // should be in spot 2!
        //    Assert.That(afterHead.Element.CompareTo(list.Get(2)), Is.EqualTo(0));

        //    Assert.That(beforeTail.Element.CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(beforeTail.Element.CompareTo(list.Get(3)), Is.EqualTo(0));

        //    Assert.That(tail.Element.CompareTo(employee), Is.EqualTo(0));
        //    Assert.That(tail.Element.CompareTo(list.Get(4)), Is.EqualTo(0));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(afterHead.Next, Is.EqualTo(beforeTail));
        //    Assert.That(beforeTail.Previous, Is.EqualTo(afterHead));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}
        //#endregion

        //#region AddBefore(element, oldElement)
        ///// <summary>
        ///// Ensure that calling AddBefore(element) on an empty list will result in an exception.
        ///// </summary>
        //[Test]
        //public void AddBeforeByElement_on_EmptyList_throws_exception_test()
        //{
        //    Employee employee = new Employee(1);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    Assert.That(() => list.AddBefore(employee, employee), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that passing element that is not in the list to AddBefore(element) results in an exception.
        ///// </summary>
        //[Test]
        //public void AddBeforeByElement_no_match_found_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee addEmployee = new Employee(2);
        //    Employee nonListEmployee = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.AddBefore(addEmployee, nonListEmployee), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that passing null value to AddBefore(element, position) results in an exception.
        ///// </summary>
        //[Test]
        //public void AddBeforeByElement_when_element_is_null_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee addEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.AddBefore(addEmployee, null), Throws.Exception.TypeOf<ArgumentNullException>());
        //}

        ///// <summary>
        ///// Checking edge case; Ensure that passing the tail element as the element will prepend to the beginning of the list without error.
        ///// </summary>
        //[Test]
        //public void AddBeforeByElement_Head_updated_and_count_increases_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee3);
        //    list.AddFirst(employee2);
        //    Assert.That(list.GetSize(), Is.EqualTo(2));

        //    list.AddBefore(employee1, list.GetFirst()); // adds before 2
        //    // order should be: 1, 2, 3

        //    // size increases
        //    Assert.That(list.GetSize(), Is.EqualTo(3));

        //    var head = list.GetHead();
        //    var middle = head.Next;
        //    var tail = list.GetTail();

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0)); // new head is 1
        //    Assert.That(middle.Element.CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(tail.Previous, Is.EqualTo(middle));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Make sure element is inserted into proper position.
        ///// </summary>
        //[Test]
        //public void AddBeforeByElement_adds_appropriately_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee3);
        //    list.AddFirst(employee1);
        //    list.AddBefore(employee2, employee3); // between 1 & 3
        //    // order should be: 1, 2, 3

        //    var head = list.GetHead();
        //    var middle = head.Next;
        //    var tail = list.GetTail();

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(head.Element, Is.EqualTo(list.Get(1)));

        //    Assert.That(middle.Element.CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(middle.Element, Is.EqualTo(list.Get(2)));

        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0));
        //    Assert.That(tail.Element, Is.EqualTo(list.Get(3)));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(tail.Previous, Is.EqualTo(middle));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Ensure that passing a element that appears multiple times in the list to AddBefore(element, oldElement) element is inserted before first instance.
        ///// </summary>
        //[Test]
        //public void AddBeforeByElement_multiple_match_found_adds_before_first_instance_test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee addEmployee = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);
        //    list.AddFirst(employee2);
        //    list.AddFirst(employee); // order will be: 1, 2, 1

        //    list.AddBefore(addEmployee, employee); // order should be: 3, 1, 2, 1

        //    var head = list.GetHead();
        //    var afterHead = head.Next;
        //    var tail = list.GetTail();
        //    var beforeTail = tail.Previous;

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(addEmployee), Is.EqualTo(0)); // newly added to spot 1
        //    Assert.That(head.Element, Is.EqualTo(list.Get(1)));

        //    Assert.That(afterHead.Element.CompareTo(employee), Is.EqualTo(0));
        //    Assert.That(afterHead.Element, Is.EqualTo(list.Get(2)));

        //    Assert.That(beforeTail.Element.CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(beforeTail.Element, Is.EqualTo(list.Get(3)));

        //    Assert.That(tail.Element.CompareTo(employee), Is.EqualTo(0));
        //    Assert.That(tail.Element, Is.EqualTo(list.Get(4)));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(afterHead.Next, Is.EqualTo(beforeTail));
        //    Assert.That(beforeTail.Previous, Is.EqualTo(afterHead));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}
        //#endregion

        //#region Remove(element)
        ///// <summary>
        ///// Make sure that calling Remove(element) on an empty list results in an exception.
        ///// </summary>
        //[Test]
        //public void RemoveByElement_On_EmptyList_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.Remove(employee), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that calling Remove(element) with element that is not in the list results in an exception.
        ///// </summary>
        //[Test]
        //public void RemoveByElement_Not_In_List_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee missingEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.Remove(missingEmployee), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Test Remove(element) on list of one, removes the first node, reduces size and adjusts head/tail.
        ///// </summary>
        //[Test]
        //public void RemoveByElement_on_list_of_1_decreases_size_sets_nulls_head_and_tail_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);
        //    list.Remove(employee1);
        //    Assert.That(list.GetSize(), Is.EqualTo(0));
        //    Assert.That(list.GetHead(), Is.Null);
        //    Assert.That(list.GetTail(), Is.Null);
        //}

        ///// <summary>
        ///// Test Remove(element) returns the element removed.
        ///// </summary>
        //[Test]
        //public void RemoveByElement_Returns_Element_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);

        //    var returnedElement = list.Remove(employee1);
        //    Assert.That(returnedElement.CompareTo(employee1), Is.EqualTo(0));
        //}

        ///// <summary>
        ///// Test Remove(element) properly updated the head when removing head element.
        ///// </summary>
        //[Test]
        //public void RemoveByElement_Head_removed_pointers_are_updated_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee1);
        //    list.AddLast(employee2);
        //    list.AddLast(employee3); // order is: 1, 2, 3

        //    var removedElement = list.Remove(employee1); // list is now: 2, 3

        //    Assert.That(list.GetSize(), Is.EqualTo(2));

        //    var head = list.GetHead();
        //    var tail = list.GetTail();

        //    Assert.That(removedElement.CompareTo(employee1), Is.EqualTo(0));

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(tail.Previous, Is.EqualTo(head));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Test Remove(element) properly updated the node points when removing middle element.
        ///// </summary>
        //[Test]
        //public void RemoveByElement_middle_removed_pointers_are_updated_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee1);
        //    list.AddLast(employee2);
        //    list.AddLast(employee3); // order is: 1, 2, 3

        //    var removedElement = list.Remove(employee2); // list is now: 1, 3

        //    Assert.That(list.GetSize(), Is.EqualTo(2));

        //    var head = list.GetHead();
        //    var tail = list.GetTail();

        //    Assert.That(removedElement.CompareTo(employee2), Is.EqualTo(0));

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(tail.Previous, Is.EqualTo(head));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Test Remove(element) properly updated the tail when removing last element.
        ///// </summary>
        //[Test]
        //public void RemoveByElement_Tail_removed_pointers_are_updated_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee1);
        //    list.AddLast(employee2);
        //    list.AddLast(employee3); // order is: 1, 2, 3

        //    var removedElement = list.Remove(employee3); // list is now: 1, 2

        //    Assert.That(list.GetSize(), Is.EqualTo(2));

        //    var head = list.GetHead();
        //    var tail = list.GetTail();

        //    Assert.That(removedElement.CompareTo(employee3), Is.EqualTo(0));

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(tail.Element.CompareTo(employee2), Is.EqualTo(0));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(tail.Previous, Is.EqualTo(head));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}


        ///// <summary>
        ///// Ensure that calling Remove(element) with element that matches multiple list elements returns only one result.
        ///// </summary>
        //[Test]
        //public void RemoveByElement_multiple_matches_removes_first_match_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee elementToRemove = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee1);
        //    list.AddLast(employee2);
        //    list.AddLast(employee2); // order is: 1, 2, 2

        //    var removedElement = list.Remove(elementToRemove); // list is now: 1, 2

        //    Assert.That(list.GetSize(), Is.EqualTo(2));

        //    var head = list.GetHead();
        //    var tail = list.GetTail();

        //    Assert.That(removedElement.CompareTo(elementToRemove), Is.EqualTo(0));

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(tail.Element.CompareTo(employee2), Is.EqualTo(0));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(tail.Previous, Is.EqualTo(head));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}
        //#endregion

        //#region Set(element, oldElement)
        ///// <summary>
        ///// Ensure that calling Set(element, oldElement) on an empty list will result in an exception.
        ///// </summary>
        //[Test]
        //public void SetByElement_on_EmptyList_throws_Exception_test()
        //{
        //    Employee employee = new Employee(1);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(() => list.Set(employee, employee), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that passing element that is not in the list to Set(element, oldElement) results in an exception.
        ///// </summary>
        //[Test]
        //public void SetByElement_no_match_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee updatedEmployee = new Employee(2);
        //    Employee nonListEmployee = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.Set(updatedEmployee, nonListEmployee), Throws.Exception.TypeOf<ApplicationException>());
        //}

        ///// <summary>
        ///// Ensure that passing null value to Set(element, oldElement) results in an exception.
        ///// </summary>
        //[Test]
        //public void SetByElement_Null_element_throws_exception_Test()
        //{
        //    Employee employee = new Employee(1);
        //    Employee updatedEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee);

        //    Assert.That(() => list.Set(updatedEmployee, null), Throws.Exception.TypeOf<ArgumentNullException>());
        //}

        ///// <summary>
        ///// Test Set(element, oldElement) updates first element on list of one.
        ///// </summary>
        //[Test]
        //public void SetByElement_updates_element_pointers_should_not_change_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee updatedEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);

        //    list.Set(updatedEmployee, employee1);

        //    // size should not change.
        //    Assert.That(list.GetSize(), Is.EqualTo(1));

        //    // new value for head
        //    Assert.That(list.GetFirst().CompareTo(updatedEmployee), Is.EqualTo(0));

        //    // check tail and head have not been changed.
        //    Assert.That(list.GetHead().Previous, Is.Null);
        //    Assert.That(list.GetHead().Next, Is.Null);
        //    Assert.That(list.GetHead(), Is.EqualTo(list.GetTail()));
        //}

        ///// <summary>
        ///// Ensure that the Set(element, oldElement) method returns the old element that has been replaced.
        ///// </summary>
        //[Test]
        //public void SetByElement_returns_oldElement_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee updatedEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);

        //    var returnedValue = list.Set(updatedEmployee, employee1);

        //    // size should not change.
        //    Assert.That(list.GetSize(), Is.EqualTo(1));

        //    // new value for head
        //    Assert.That(returnedValue.CompareTo(employee1), Is.EqualTo(0));
        //}

        ///// <summary>
        ///// Ensure that passing a element that appears multiple times in the list to Set(element, oldElement) only first instance is replaced.
        ///// </summary>
        //[Test]
        //public void SetByElement_Multiple_Matching_changes_first_instance_only_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee3 = new Employee(3);
        //    Employee updateEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddFirst(employee1);
        //    list.AddLast(employee3);
        //    list.AddLast(employee3);

        //    var oldElement = list.Set(updateEmployee, employee3);

        //    Assert.That(list.GetFirst().CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(list.Get(2).CompareTo(updateEmployee), Is.EqualTo(0));
        //    Assert.That(list.GetLast().CompareTo(employee3), Is.EqualTo(0));
        //}
        //#endregion


        //#region Insert()
        ///// <summary>
        ///// Test that Insert() can insert into an empty list and update the head/tail
        ///// </summary>
        //[Test]
        //public void Insert_EmptyList_increases_size_updates_head_and_tail_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    Assert.That(list.GetSize(), Is.EqualTo(0));

        //    list.Insert(employee1);

        //    // size increases
        //    Assert.That(list.GetSize(), Is.EqualTo(1));

        //    Assert.That(list.GetFirst().CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(list.GetLast().CompareTo(employee1), Is.EqualTo(0));

        //    // check that end pointers are still null
        //    Assert.That(list.GetHead().Previous, Is.EqualTo(null));
        //    Assert.That(list.GetTail().Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Test that Insert() adds an element to the list in ascending order spot
        ///// </summary>
        //[Test]
        //public void Insert_Adds_inbetween_head_and_tail_when_value_between_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employee3);
        //    list.AddFirst(employee1);

        //    list.Insert(employee2); // order should be: 1, 2, 3

        //    var head = list.GetHead();
        //    var middle = head.Next;
        //    var tail = list.GetTail();

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(middle.Element.CompareTo(employee2), Is.EqualTo(0)); // newly added value
        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(tail.Previous, Is.EqualTo(middle));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Edge case; check that Insert() will insert into the head position without error.
        ///// </summary>
        //[Test]
        //public void Insert_at_Head_Position_when_smallest_list_value_Test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee3);
        //    list.AddFirst(employee2);

        //    list.Insert(employee1);  // order should be: 1, 2, 3

        //    var head = list.GetHead();
        //    var middle = head.Next;
        //    var tail = list.GetTail();

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0)); // newly added value
        //    Assert.That(middle.Element.CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(tail.Previous, Is.EqualTo(middle));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Edge case; check that Insert() will insert into the tail position without error.
        ///// </summary>
        //[Test]
        //public void InsertTailPositionTest()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee2);
        //    list.AddFirst(employee1);

        //    list.Insert(employee3);  // order should be: 1, 2, 3

        //    var head = list.GetHead();
        //    var middle = head.Next;
        //    var tail = list.GetTail();

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(middle.Element.CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0)); // newly added value

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(tail.Previous, Is.EqualTo(middle));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Test that Insert() can handle inserting when duplicates exist in the list already.
        ///// </summary>
        //[Test]
        //public void Insert_duplicate_values_in_list_still_maintain_order_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee addEmployee = new Employee(3);

        //    LinkedList<Employee> list = new LinkedList<Employee>();

        //    list.AddLast(employee2);
        //    list.AddFirst(employee1);
        //    list.AddFirst(employee1); // duplicate 1's in front, order will be: 1, 1, 2

        //    list.Insert(addEmployee); // order should be: 1, 1, 2, 3

        //    var head = list.GetHead();
        //    var afterHead = head.Next;
        //    var tail = list.GetTail();
        //    var beforeTail = tail.Previous;

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(head.Element, Is.EqualTo(list.Get(1)));

        //    Assert.That(afterHead.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(afterHead.Element, Is.EqualTo(list.Get(2)));

        //    Assert.That(beforeTail.Element.CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(beforeTail.Element, Is.EqualTo(list.Get(3)));

        //    Assert.That(tail.Element.CompareTo(addEmployee), Is.EqualTo(0)); // newly added value
        //    Assert.That(tail.Element, Is.EqualTo(list.Get(4)));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(afterHead.Next, Is.EqualTo(beforeTail));
        //    Assert.That(beforeTail.Previous, Is.EqualTo(afterHead));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}

        ///// <summary>
        ///// Test that Insert() can handle inserting when value to add exists in the list already.
        ///// </summary>
        //[Test]
        //public void Insert_new_value_exists_in_list_adds_in_order_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);

        //    Employee addEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employee3);
        //    list.AddFirst(employee2);
        //    list.AddFirst(employee1); // order will be: 1, 2, 3

        //    list.Insert(addEmployee); // order should be: 1, 2, 2, 3

        //    var head = list.GetHead();
        //    var afterHead = head.Next;
        //    var tail = list.GetTail();
        //    var beforeTail = tail.Previous;

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(head.Element, Is.EqualTo(list.Get(1)));

        //    Assert.That(afterHead.Element.CompareTo(addEmployee), Is.EqualTo(0)); // newly added value
        //    Assert.That(afterHead.Element, Is.EqualTo(list.Get(2)));

        //    Assert.That(beforeTail.Element.CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(beforeTail.Element, Is.EqualTo(list.Get(3)));

        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0));
        //    Assert.That(tail.Element, Is.EqualTo(list.Get(4)));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(afterHead.Next, Is.EqualTo(beforeTail));
        //    Assert.That(beforeTail.Previous, Is.EqualTo(afterHead));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}


        ///// <summary>
        /////Test that Insert() can handle inserting when list is not ordered
        ///// </summary>
        //[Test]
        //public void Insert_new_value_in_non_ordered_list_assigns_in_natural_order_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee4 = new Employee(4);
        //    Employee employee3 = new Employee(3);

        //    Employee addEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employee3);
        //    list.AddFirst(employee4);
        //    list.AddFirst(employee1); // order will be: 1, 4, 3

        //    list.Insert(addEmployee); // order should be: 1, 2, 4, 3

        //    var head = list.GetHead();
        //    var afterHead = head.Next;
        //    var tail = list.GetTail();
        //    var beforeTail = tail.Previous;

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(head.Element, Is.EqualTo(list.Get(1)));

        //    Assert.That(afterHead.Element.CompareTo(addEmployee), Is.EqualTo(0)); // newly added value
        //    Assert.That(afterHead.Element, Is.EqualTo(list.Get(2)));

        //    Assert.That(beforeTail.Element.CompareTo(employee4), Is.EqualTo(0));
        //    Assert.That(beforeTail.Element, Is.EqualTo(list.Get(3)));

        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0));
        //    Assert.That(tail.Element, Is.EqualTo(list.Get(4)));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(afterHead.Next, Is.EqualTo(beforeTail));
        //    Assert.That(beforeTail.Previous, Is.EqualTo(afterHead));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}

        ///// <summary>
        /////Test that Insert() can handle inserting when list is not ordered, largest number is first
        ///// </summary>
        //[Test]
        //public void Insert_new_value_in_non_ordered_list_assigns_in_natural_order_largest_number_is_first_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee4 = new Employee(4);
        //    Employee employee3 = new Employee(3);

        //    Employee addEmployee = new Employee(2);

        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employee3);
        //    list.AddFirst(employee1);
        //    list.AddFirst(employee4); // order will be: 4, 1, 3

        //    list.Insert(addEmployee); // order should be: 4, 1, 2, 3

        //    var head = list.GetHead();
        //    var afterHead = head.Next;
        //    var tail = list.GetTail();
        //    var beforeTail = tail.Previous;

        //    // check all values are correct after add
        //    Assert.That(head.Element.CompareTo(employee4), Is.EqualTo(0));
        //    Assert.That(head.Element, Is.EqualTo(list.Get(1)));

        //    Assert.That(afterHead.Element.CompareTo(employee1), Is.EqualTo(0));
        //    Assert.That(afterHead.Element, Is.EqualTo(list.Get(2)));

        //    Assert.That(beforeTail.Element.CompareTo(addEmployee), Is.EqualTo(0));// newly added value
        //    Assert.That(beforeTail.Element, Is.EqualTo(list.Get(3)));

        //    Assert.That(tail.Element.CompareTo(employee3), Is.EqualTo(0));
        //    Assert.That(tail.Element, Is.EqualTo(list.Get(4)));

        //    // check that end pointers are still null and that nodes point to each other
        //    Assert.That(head.Previous, Is.EqualTo(null));
        //    Assert.That(afterHead.Next, Is.EqualTo(beforeTail));
        //    Assert.That(beforeTail.Previous, Is.EqualTo(afterHead));
        //    Assert.That(tail.Next, Is.EqualTo(null));
        //}
        //#endregion


        //#region SortAscending()
        ///// <summary>
        ///// We run SortAscending() on an empty list, no exceptions should be thrown.
        ///// </summary>
        //[Test]
        //public void SortAscending_on_EmptyList_does_not_throw_exception_test()
        //{
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.SortAscending();
        //    Assert.That(list.IsEmpty());
        //    Assert.That(list.GetHead(), Is.Null);
        //    Assert.That(list.GetTail(), Is.Null);
        //}

        ///// <summary>
        ///// We run SortAscending() on a list of 1, no changes should be made.
        ///// </summary>
        //[Test]
        //public void SortAscending_on_list_of_1_does_not_change_anything_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.Insert(employee1);
        //    list.SortAscending();
        //    Assert.That(list.GetSize(), Is.EqualTo(1));
        //    Assert.That(list.GetFirst(), Is.EqualTo(employee1));
        //    Assert.That(list.GetHead().Next, Is.Null);
        //    Assert.That(list.GetHead().Previous, Is.Null);
        //    Assert.That(list.GetTail(), Is.EqualTo(list.GetHead()));
        //}

        ///// <summary>
        ///// We run SortAscending() on a sorted list of 2, no changes should be made.
        ///// </summary>
        //[Test]
        //public void SortAscending_on_sorted_list_of_2_does_not_change_anything_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.Insert(employee1);
        //    list.Insert(employee2);
        //    list.SortAscending();
        //    Assert.That(list.GetSize(), Is.EqualTo(2));
        //    Assert.That(list.GetFirst(), Is.EqualTo(employee1));
        //    Assert.That(list.GetLast(), Is.EqualTo(employee2));
        //    Assert.That(list.GetHead().Next, Is.EqualTo(list.GetTail()));
        //    Assert.That(list.GetHead().Previous, Is.Null);
        //    Assert.That(list.GetTail().Previous, Is.EqualTo(list.GetHead()));
        //    Assert.That(list.GetTail().Next, Is.Null);
        //}

        ///// <summary>
        ///// We run SortAscending() on a sorted list of 3, no changes should be made.
        ///// </summary>
        //[Test]
        //public void SortAscending_on_sorted_list_of_3_does_not_change_anything_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.Insert(employee1);
        //    list.Insert(employee2);
        //    list.Insert(employee3);
        //    list.SortAscending();

        //    Assert.That(list.GetSize(), Is.EqualTo(3));
        //    Assert.That(list.GetFirst(), Is.EqualTo(employee1));
        //    Assert.That(list.GetHead().Next.Element, Is.EqualTo(employee2));
        //    Assert.That(list.GetLast(), Is.EqualTo(employee3));
        //    Assert.That(list.GetHead().Next, Is.EqualTo(list.GetTail().Previous));
        //    Assert.That(list.GetHead().Previous, Is.Null);
        //    Assert.That(list.GetTail().Previous, Is.EqualTo(list.GetHead().Next));
        //    Assert.That(list.GetTail().Next, Is.Null);
        //}

        ///// <summary>
        ///// We run SortAscending() on an unsorted list of 2, should sort the values
        ///// </summary>
        //[Test]
        //public void SortAscending_on_unsorted_list_of_2_sorts_ascending_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employee1);
        //    list.AddFirst(employee2);
        //    list.SortAscending();
        //    Assert.That(list.GetSize(), Is.EqualTo(2));
        //    Assert.That(list.GetFirst(), Is.EqualTo(employee1));
        //    Assert.That(list.GetLast(), Is.EqualTo(employee2));
        //    Assert.That(list.GetHead().Next, Is.EqualTo(list.GetTail()));
        //    Assert.That(list.GetHead().Previous, Is.Null);
        //    Assert.That(list.GetTail().Previous, Is.EqualTo(list.GetHead()));
        //    Assert.That(list.GetTail().Next, Is.Null);
        //}

        ///// <summary>
        ///// We run SortAscending() on an unsorted list of 3, should sort the values
        ///// </summary>
        //[Test]
        //public void SortAscending_on_Unsorted_list_of_3_sorts_ascending_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee employee3 = new Employee(3);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employee1);
        //    list.AddFirst(employee2);
        //    list.AddFirst(employee3);
        //    list.SortAscending();

        //    Assert.That(list.GetSize(), Is.EqualTo(3));
        //    Assert.That(list.GetFirst(), Is.EqualTo(employee1));
        //    Assert.That(list.GetHead().Next.Element, Is.EqualTo(employee2));
        //    Assert.That(list.GetLast(), Is.EqualTo(employee3));
        //    Assert.That(list.GetHead().Next, Is.EqualTo(list.GetTail().Previous));
        //    Assert.That(list.GetHead().Previous, Is.Null);
        //    Assert.That(list.GetTail().Previous, Is.EqualTo(list.GetHead().Next));
        //    Assert.That(list.GetTail().Next, Is.Null);
        //}

        ///// <summary>
        ///// We run SortAscending() on a large unsorted list with duplicates, should sort the values
        ///// </summary>
        //[Test]
        //public void SortAscending_on_large_Unsorted_list_with_duplicates_sorts_ascending_test()
        //{
        //    Employee employee1 = new Employee(1);
        //    Employee employee2 = new Employee(2);
        //    Employee duplicate2 = new Employee(2);
        //    Employee employee3 = new Employee(3);
        //    Employee employee4 = new Employee(4);
        //    Employee employee5 = new Employee(5);
        //    LinkedList<Employee> list = new LinkedList<Employee>();
        //    list.AddLast(employee1);
        //    list.AddFirst(employee2);
        //    list.AddFirst(duplicate2); // duplicate
        //    list.AddFirst(employee3);
        //    list.AddLast(employee4);
        //    list.AddFirst(employee5); // list is:5, 3, 2, 2, 1, 4
        //    list.SortAscending();

        //    Assert.That(list.GetSize(), Is.EqualTo(6));
        //    Assert.That(list.GetFirst(), Is.EqualTo(employee1));
        //    Assert.That(list.Get(2).CompareTo(duplicate2), Is.EqualTo(0));
        //    Assert.That(list.Get(3).CompareTo(employee2), Is.EqualTo(0));
        //    Assert.That(list.Get(4), Is.EqualTo(employee3));
        //    Assert.That(list.Get(5), Is.EqualTo(employee4));
        //    Assert.That(list.GetLast(), Is.EqualTo(employee5));

        //    Assert.That(list.GetHead().Next.Element.CompareTo(duplicate2), Is.EqualTo(0));
        //    Assert.That(list.GetHead().Previous, Is.Null);
        //    Assert.That(list.GetTail().Previous.Element, Is.EqualTo(employee4));
        //    Assert.That(list.GetTail().Next, Is.Null);
        //}
        //#endregion

        //#endregion

    }

}