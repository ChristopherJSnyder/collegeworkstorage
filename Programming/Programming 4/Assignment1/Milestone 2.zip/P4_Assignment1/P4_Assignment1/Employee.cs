﻿using System;

namespace P4_Assignment1
{
    public class Employee : IComparable<Employee>
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public Employee(int employeeID)
        {
            this.EmployeeID = employeeID;
            this.FirstName = null;
            this.LastName = null;
        }

        public Employee(int employeeID, string firstName, string lastName)
        {
            this.EmployeeID = employeeID;
            this.FirstName = firstName;
            this.LastName = lastName;
        }
        
        public int CompareTo(Employee other)
        {
            return this.EmployeeID.CompareTo(other.EmployeeID);
        }

        public override string ToString()
        {
            if (FirstName == null)
            {
                FirstName = "null";
            }

            if (LastName == null)
            {
                LastName = "null";
            }
            
            return EmployeeID + " " + FirstName + " " + LastName;
        }
    }

    public class Node<T>
    {
        public T Element { get; set; }
        public Node<T> Previous { get; set; }
        public Node<T> Next { get; set; }

        public Node()
        {
            this.Element = default(T);
            this.Previous = default(Node<T>);
            this.Next = default(Node<T>);
        }

        public Node(T Element)
        {
            this.Element = Element;

        }

        public Node(T Element, Node<T> Previous, Node<T> Next)
        {

            this.Element = Element;
            this.Previous = Previous;
            this.Next = Next;

        }

    }

    public class LinkedList<T>
    {
        public Node<T> Head { get; set; }
        public Node<T> Tail { get; set; }
        public int Size { get; set; }

        public LinkedList()
        {
            
        }

        public void AddFirst (T Element)
        {
           
             Node<T> firstnode = new Node<T>(Element);

            Node<T> Oldhead = Head;
            Head = firstnode; 
            

            if (this.Size == 0)
            {
                this.Tail = firstnode;
            }
            else
            {
                this.Head.Next = Oldhead;
                Oldhead.Previous= Head;
            }
            Size++;
        }


        public void Clear()
        {

            Size = 0;
            Head = null;
            Tail = null;

        }

        public bool IsEmpty()
        {
            return this.Size == 0;
            //if (this.Size == 0)
            //{
            //    return true;
            //}

            //else
            //{
            //    return false;
            //}
        }

        public Node<T> GetHead()
        {
            return this.Head;
        }

        public Node<T> GetTail()
        {
            return this.Tail;
        }

        public T GetFirst()
        {
            if (IsEmpty())
            {
                throw new ApplicationException("No Head to get");
            }
            else
            {
                return Head.Element;
            }
        }

        public T  GetLast()
        {
            if (IsEmpty())
            {
                throw new ApplicationException("No Tail to get");
            }
            else
            {
                return Tail.Element;
            }
            
        }

        public int GetSize()
        {
            return this.Size;
        }

        public T SetFirst(T element)
        {
            if (IsEmpty())
            {
                throw new ApplicationException("List is empty.");
            }
            T replaced = Head.Element; 
            this.Head.Element = element;
            return replaced;
        }

        public T SetLast(T element)
        {
            if (IsEmpty())
            {
                throw new ApplicationException("List is empty");
            }
            T replaced = Tail.Element;
            this.Tail.Element = element;
            return replaced;
        }


        public void AddLast(T Element)
        {
            Node<T> newnode = new Node<T>(Element);
           
          

            if (this.Size == 0)
            {
                this.Tail = newnode;
                this.Head = newnode;
            }

            else
            {


                Node <T> nodenewtail = new Node<T>(Element);
                Node<T> currenttail = Tail;
                Node<T> aftercurrenttail = Tail.Next;

                Node<T> Oldtail = Tail.Next;

                Tail = nodenewtail;
                Tail.Previous = Oldtail;
               
                

                



                //newnode.Next = Tail;
                //newnode.Previous = Tail;
                //Tail.Previous = null;
                //Tail.Next = null;


                //Tail = newnode;

                
            }
            Size++;
        }

        public T RemoveFirst()
        {
            if (IsEmpty())
            {
                throw new ApplicationException("List is empty.");
            }

            T removed = Head.Element;
            Head.Previous = null;
            

          
            Size--;
            return removed;
        }

        public Node <T> RemoveLast()
        {
            Node<T> oldtail = null;

            if (IsEmpty())
            {
                throw new ApplicationException("List is empty.");
            }
            
            if (Size == 1)
            {
                oldtail = Tail;
                Head = null;
                Tail = null;
                Size = 0;
            }

            if (Size == 2)
            {
                Head = Tail;
                Tail.Previous = null;
                Tail.Next = null;
                
            }

            return oldtail;
        }




        public Node<T> GetNodeByPosition(int position)
        {
            if (position < 0 || IsEmpty() || position > Size)
            {
                throw new ApplicationException("Position cannot be below zero");
            }
            Node<T> current = Head;
           
            for (int currentpos = 1; currentpos < position; currentpos++)
            {
                current = current.Next;
            }

            return current;
        }


        public T Get(int position)
        {
            Node<T> node = GetNodeByPosition(position);
            return node.Element;
        }


        public T Remove(int position)
        {
            if (position == 0)
            {
                throw new ApplicationException("Cannot remove position 0");
            }

            Node<T> nodeToRemove = GetNodeByPosition(position);
            T oldElement = nodeToRemove.Element;
            
            if (nodeToRemove == Head)
            {
                RemoveFirst();
                

            }

            if (nodeToRemove == Tail)
            {
                RemoveLast();
                
            }

            else
            {
                Node<T> previous = nodeToRemove.Previous;
                Node<T> next = nodeToRemove.Next;
                previous.Next = nodeToRemove.Next;
                previous.Previous = nodeToRemove.Previous;


                Size--;
                nodeToRemove.Next = nodeToRemove.Previous;
            }
            // if the nodeToRemove is the head, removeFirst()
            // if it's the tail removeLast()
            // otherwise remove between*
            // nodeToRemove.Next and nodeToRemove.Previous need to point at each other
            // by the time you're done NodeToRemove will not be pointed at by anything

            return oldElement;
        }


        public T Set (T elementtoadd, int position)
        {
         
            if (position <= 0)
            {
                throw new ApplicationException("Cannot set below position 0");
            }

            T element = Get(position);
            
            T replaced = element;
            element = elementtoadd;
            return replaced;
            
        }

        public T AddAfter(T elementtoadd, int position)
        {
            if (position < 0)
            {
                throw new ApplicationException("Position cannot be below zero");
            }

            if (position > Size)
            {
                throw new ApplicationException("Position cannot be greater than the size of the list");
            }

            if (IsEmpty())
            {
                throw new ApplicationException("List is empty - nothing to add after");
            }

            if (position == Size)
            {
                Node<T> newnode = new Node<T>(elementtoadd);
                AddLast(elementtoadd);

                
                
                

                return elementtoadd;
            }

            else
            {
                Node<T> newnode = new Node<T>(elementtoadd);
                Node<T> node1 = GetNodeByPosition(position);
                Node<T> node2 = node1.Next;

                node1.Next = newnode;
                newnode.Previous = node1;
                newnode.Next = node2;
                node2.Previous = newnode;
                Size++;
                return elementtoadd;


                // addafter.next and formeraddafter.next = 
            

                
            }

          

            






        }


        public void AddBefore(T elementtoadd, int position)
        {
            if (position < 0)
            {
                throw new ApplicationException("Position cannot be below zero");
            }

         
            T element = Get(position);

            element = elementtoadd;
            

        }







    }
}
