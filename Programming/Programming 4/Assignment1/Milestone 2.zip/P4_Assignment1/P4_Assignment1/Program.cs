﻿using System;

namespace P4_Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Test your code here if you want!
            // Example:
            // LinkedList<Employee> list = new LinkedList<Employee>();
            // Employee e1 = new Employee(1);
            // list.AddFirst(e1);
            // Console.WriteLine(list.PrintList()); // make a print list for debugging maybe?
        }
    }
}
